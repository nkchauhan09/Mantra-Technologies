import './App.css';
import CustomerForm from './CustomerForm';

function App() {
  return (
    <div className="App">
      <CustomerForm></CustomerForm>
    </div>
  );
}

export default App;
